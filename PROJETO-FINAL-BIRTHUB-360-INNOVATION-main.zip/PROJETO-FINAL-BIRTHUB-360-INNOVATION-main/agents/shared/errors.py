class AgentToolError(Exception):
    pass
